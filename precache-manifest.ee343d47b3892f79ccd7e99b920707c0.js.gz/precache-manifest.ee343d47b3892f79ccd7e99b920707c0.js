self.__precacheManifest = [
  {
    "revision": "1d4ca9142d8e36b58f5f4eae45cfcf7f",
    "url": "/index.html"
  },
  {
    "revision": "ef36c30e351f148b13c8",
    "url": "/bundle.js"
  },
  {
    "revision": "b197ce124d69182fe3552bf0db1af5b8",
    "url": "/assets/icon/logo_48x48.png"
  },
  {
    "revision": "9dafb10afa5958118d7ed121744d21a0",
    "url": "/assets/icon/logo_32x32.png"
  },
  {
    "revision": "88c79d256492b6668a5b20f6f08481f9",
    "url": "/assets/icon/logo_16x16.png"
  }
];