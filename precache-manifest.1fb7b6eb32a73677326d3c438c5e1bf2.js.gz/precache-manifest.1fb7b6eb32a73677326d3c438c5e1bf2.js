self.__precacheManifest = [
  {
    "revision": "99411a56b1236d612f987b3e45533fb1",
    "url": "/index.html"
  },
  {
    "revision": "5f571d2fe4fe73779805",
    "url": "/bundle.js"
  },
  {
    "revision": "10bb853479bab7813b13572bb45f9785",
    "url": "/assets/logo.svg"
  },
  {
    "revision": "8e63ffb86d4cfae6aa7ce310e8e0bfcc",
    "url": "/assets/id.svg"
  },
  {
    "revision": "e8fdae05f18fa95365e13bcef2c6964e",
    "url": "/assets/files.svg"
  },
  {
    "revision": "c49ebda2a55ff6847241621c0925b783",
    "url": "/assets/assets.svg"
  },
  {
    "revision": "08cbb35523572440b86ca0bcdf8d90fe",
    "url": "/assets/applications.svg"
  },
  {
    "revision": "fbffbfd975b6423e198c4059c9221bdf",
    "url": "/assets/ai.svg"
  }
];