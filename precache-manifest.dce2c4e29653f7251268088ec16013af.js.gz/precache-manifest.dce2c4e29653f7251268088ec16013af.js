self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fbffbfd975b6423e198c4059c9221bdf",
    "url": "/assets/ai.svg"
  },
  {
    "revision": "08cbb35523572440b86ca0bcdf8d90fe",
    "url": "/assets/applications.svg"
  },
  {
    "revision": "c49ebda2a55ff6847241621c0925b783",
    "url": "/assets/assets.svg"
  },
  {
    "revision": "e8fdae05f18fa95365e13bcef2c6964e",
    "url": "/assets/files.svg"
  },
  {
    "revision": "8e63ffb86d4cfae6aa7ce310e8e0bfcc",
    "url": "/assets/id.svg"
  },
  {
    "revision": "00debcf6cf0789a19cee2278011afcd4",
    "url": "/assets/js/particles.min.js"
  },
  {
    "revision": "4e3fd50f0db8d43930098e6d75f1d980",
    "url": "/assets/logo.svg"
  },
  {
    "revision": "7391d6b354df50e7d412ec5752813490",
    "url": "/assets/particles.json"
  },
  {
    "revision": "8d5f74ed6d8f529acf5f",
    "url": "/bundle.js"
  },
  {
    "revision": "b2eb8b29878548e8a057c15477adc6c2",
    "url": "/index.html"
  }
]);