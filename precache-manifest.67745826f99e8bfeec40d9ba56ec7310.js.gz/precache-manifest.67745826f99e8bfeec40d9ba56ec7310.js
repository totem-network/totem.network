self.__precacheManifest = [
  {
    "revision": "023aceea3cc4055a99a9061544efe382",
    "url": "/index.html"
  },
  {
    "revision": "67b5a87d8928bf122f45",
    "url": "/bundle.js"
  },
  {
    "revision": "c3ab2bf931f880c1323ed129dae727af",
    "url": "/assets/particles.json"
  },
  {
    "revision": "4e3fd50f0db8d43930098e6d75f1d980",
    "url": "/assets/logo.svg"
  },
  {
    "revision": "00debcf6cf0789a19cee2278011afcd4",
    "url": "/assets/js/particles.min.js"
  },
  {
    "revision": "8e63ffb86d4cfae6aa7ce310e8e0bfcc",
    "url": "/assets/id.svg"
  },
  {
    "revision": "e8fdae05f18fa95365e13bcef2c6964e",
    "url": "/assets/files.svg"
  },
  {
    "revision": "c49ebda2a55ff6847241621c0925b783",
    "url": "/assets/assets.svg"
  },
  {
    "revision": "08cbb35523572440b86ca0bcdf8d90fe",
    "url": "/assets/applications.svg"
  },
  {
    "revision": "fbffbfd975b6423e198c4059c9221bdf",
    "url": "/assets/ai.svg"
  }
];